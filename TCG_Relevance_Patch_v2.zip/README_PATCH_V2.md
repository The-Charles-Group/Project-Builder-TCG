
# Relevance Patch v2 — Sparse High %, Dept Gating, Budget/Timeline Awareness

**Goal:** prevent "everything is ~90%" by enforcing a few clear winners and using business context.

### What changes
1) **Department gating** (to your 6 departments) — only top-2 depts are allowed to score high.
2) **Execution > Strategy bias** — activation/trafficking/reporting outrank decks.
3) **Budget penalty** — if estimated hours × blended rate would blow the stated budget, downweight.
4) **Sparsity shaping** — at most `high_cap` deliverables can appear ≥85%. Others are compressed below 70%.
5) **Self-check meta** — API returns detected departments and budget for transparency.

### API
- FastAPI: `POST /api/step2/ai/weights_v2`
- Flask:   `POST /api/step2/ai/weights_v2`
Body: `{ "rfp_text": "..." }`

### UI (Step 2A)
Use `static/static_weights_v2.js` + `.css` to render the results and bands.

### Tuning knobs
Edit `server/ai_relevance_v2.py` → `self.cfg`:
- `dept_topK, dept_penalty, dept_bonus`
- `strategy_penalty, execution_bonus`
- `high_cap, band_top, band_mid, band_low`
- `blended_rate, overbudget_penalty`

### Data
If you maintain `data/AI_Matching_Rules_full.xlsx` with an `AI_Index` sheet the engine will use it; otherwise it auto-builds from your DB workbook (`Deliverable_Index` + `All_Task_Rows`).  Hours are estimated from any columns containing "hour|hrs".
