
import asyncio
from fastapi import APIRouter, Request, Body
from pydantic import BaseModel
from typing import Optional, Dict, Any, List
from .utils import preload_index, score_text, jsonify_scored
from .stream import publish_event, ensure_job

router = APIRouter()

class AnalyzeDeepPayload(BaseModel):
    rfp_text: Optional[str] = ""
    job_id: Optional[str] = None

@router.post("/analyze_deep2")
async def analyze_deep2(request: Request, payload: AnalyzeDeepPayload = Body(...)):
    job_id = payload.job_id or ensure_job(request.app)
    publish = lambda data: publish_event(request.app, job_id, data)
    text = (payload.rfp_text or "").strip()
    if not text:
        publish({"stage": "error", "message": "Empty rfp_text"})
        return {"job_id": job_id, "status": "error"}
    publish({"stage": "chunking"})
    chunks = [c.strip() for c in text.split("\n\n") if c.strip()][:12]
    results: List[Dict[str, Any]] = []
    async def chunk_analyze(i: int, ck: str):
        await asyncio.sleep(0.2)  # simulate latency; replace with real LLM call
        idx = getattr(request.app.state, "ai_index", None) or preload_index()
        scored = jsonify_scored(score_text(ck, idx, top_k=10), idx)
        return {"i": i, "deliverables": scored}
    publish({"stage": "analyzing", "total": len(chunks)})
    async with asyncio.TaskGroup() as tg:
        tasks = [tg.create_task(chunk_analyze(i, ck)) for i, ck in enumerate(chunks)]
    for t in tasks:
        results.append(t.result())
        publish({"stage": "partial", "count": len(results)})
    combined: Dict[str, float] = {}
    for r in results:
        for d in r["deliverables"]:
            code = d["Deliverable_Code"]
            combined[code] = max(combined.get(code, 0.0), float(d["confidence"]))
    merged = [{"Deliverable_Code": c, "confidence": v} for c, v in combined.items()]
    publish({"stage": "done", "count": len(merged)})
    return {"job_id": job_id, "status": "completed", "deliverables": merged}
