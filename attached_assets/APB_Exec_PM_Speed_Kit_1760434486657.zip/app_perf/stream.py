
import asyncio, json, time, uuid
from fastapi import APIRouter, Request
from starlette.responses import StreamingResponse

router = APIRouter()

def ensure_job(app) -> str:
    jobs = getattr(app.state, "jobs", None)
    if jobs is None:
        app.state.jobs = {}
        jobs = app.state.jobs
    job_id = uuid.uuid4().hex[:12]
    jobs[job_id] = {"ts": time.time(), "queue": asyncio.Queue(maxsize=100)}
    return job_id

def publish_event(app, job_id: str, data: dict):
    jobs = getattr(app.state, "jobs", {})
    if job_id in jobs:
        q = jobs[job_id]["queue"]
        try:
            q.put_nowait(json.dumps(data))
        except asyncio.QueueFull:
            pass

@router.get("/{job_id}")
async def stream(request: Request, job_id: str):
    jobs = getattr(request.app.state, "jobs", {})
    if job_id not in jobs:
        async def not_found():
            yield "data: " + json.dumps({"stage": "not_found"}) + "\\n\\n"
        return StreamingResponse(not_found(), media_type="text/event-stream")
    q = jobs[job_id]["queue"]
    async def gen():
        yield "data: " + json.dumps({"stage": "connected"}) + "\\n\\n"
        while True:
            if await request.is_disconnected():
                break
            try:
                msg = await asyncio.wait_for(q.get(), timeout=10.0)
                yield "data: " + msg + "\\n\\n"
            except asyncio.TimeoutError:
                yield "data: " + json.dumps({"stage": "keepalive"}) + "\\n\\n"
    return StreamingResponse(gen(), media_type="text/event-stream")
