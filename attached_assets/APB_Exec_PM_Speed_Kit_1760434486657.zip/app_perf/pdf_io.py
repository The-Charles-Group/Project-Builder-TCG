
import os, hashlib, fitz  # PyMuPDF
from typing import Optional

CACHE_DIR = os.getenv("PDF_TEXT_CACHE_DIR", "/tmp/pdf_text_cache")
os.makedirs(CACHE_DIR, exist_ok=True)

def _sha(b: bytes) -> str:
    import hashlib
    return hashlib.sha256(b).hexdigest()

def extract_text_from_bytes(pdf_bytes: bytes) -> str:
    doc = fitz.open(stream=pdf_bytes, filetype="pdf")
    parts = []
    for p in doc:
        parts.append(p.get_text("text"))
    doc.close()
    return "\n".join(parts)

def extract_text_cached(pdf_bytes: bytes) -> str:
    h = _sha(pdf_bytes or b"")
    fp = os.path.join(CACHE_DIR, f"{h}.txt")
    if os.path.exists(fp):
        try:
            with open(fp, "r", encoding="utf-8") as f:
                return f.read()
        except Exception:
            pass
    txt = extract_text_from_bytes(pdf_bytes)
    try:
        with open(fp, "w", encoding="utf-8") as f:
            f.write(txt)
    except Exception:
        pass
    return txt
