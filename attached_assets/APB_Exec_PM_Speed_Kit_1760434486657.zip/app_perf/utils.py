
import os, re, json, math, pickle, hashlib, time
from typing import Dict, List, Tuple
import pandas as pd

WORD = re.compile(r"[A-Za-z0-9]{2,}")

def tokenize(text: str) -> List[str]:
    return [t.lower() for t in WORD.findall(text or "")]

def _idf(df_counts: Dict[str,int], N:int) -> Dict[str,float]:
    return {t: math.log((N + 1) / (c + 1)) + 1.0 for t, c in df_counts.items()}

def _tfidf_vec(tokens: List[str], idf: Dict[str,float]) -> Dict[str,float]:
    if not tokens: return {}
    tf = {}
    for t in tokens:
        if t in idf:
            tf[t] = tf.get(t, 0.0) + 1.0
    if not tf: return {}
    inv_sum = 1.0 / sum(tf.values())
    for t in tf:
        tf[t] *= inv_sum
    return {t: tf[t] * idf[t] for t in tf}

def _cosine(q: Dict[str,float], d: Dict[str,float]) -> float:
    if not q or not d: return 0.0
    num = 0.0; qn=0.0; dn=0.0
    for t, w in q.items():
        num += w * d.get(t, 0.0)
        qn  += w * w
    for w in d.values():
        dn += w * w
    if qn<=0 or dn<=0: return 0.0
    return num / math.sqrt(qn*dn)

def _hash_path(path:str) -> str:
    try:
        st = os.stat(path)
        return f"{int(st.st_mtime)}:{st.st_size}"
    except:
        return "0:0"

CACHE_DIR = os.getenv("AI_INDEX_CACHE_DIR", "/tmp")
CACHE_FILE = os.path.join(CACHE_DIR, "ai_deliverable_index.pkl")

def build_index_from_excel(xlsx_path: str) -> Dict:
    df = pd.read_excel(xlsx_path, sheet_name=None, engine="openpyxl")
    sheet = None
    for k in df.keys():
        if "index" in k.lower() or "deliver" in k.lower():
            sheet = df[k]; break
    if sheet is None:
        sheet = list(df.values())[0]
    rows = []
    for _, r in sheet.iterrows():
        code = str(r.get("Deliverable_Code") or r.get("Code") or r.get("ID") or "").strip()
        name = str(r.get("Deliverable_Name") or r.get("Name") or r.get("Title") or "").strip()
        desc = str(r.get("Description") or r.get("Desc") or "").strip()
        if not code and not name: 
            continue
        text = f"{name}\n{desc}".strip()
        rows.append((code or name or f"ROW{len(rows)+1}", name or code or "", text))
    if not rows:
        raise RuntimeError("No deliverables found in workbook")
    df_counts = {}
    docs: Dict[str, Dict[str,float]] = {}
    for code, name, text in rows:
        toks = tokenize(text)
        seen = set()
        for t in toks:
            if t not in seen:
                df_counts[t] = df_counts.get(t,0)+1
                seen.add(t)
        docs[code] = {"_name": name, "_tokens": toks}
    N = len(rows)
    idf = _idf(df_counts, N)
    doc_vecs: Dict[str, Dict[str,float]] = {}
    for code, info in docs.items():
        doc_vecs[code] = _tfidf_vec(info["_tokens"], idf)
    return {
        "idf": idf,
        "docs": {code: vec for code, vec in doc_vecs.items()},
        "names": {code: docs[code]["_name"] for code in docs},
        "meta": {"N": N, "xlsx_sig": _hash_path(xlsx_path)}
    }

def preload_index(xlsx_path: str = "AI_Matching_Rules_full.xlsx") -> Dict:
    sig = _hash_path(xlsx_path)
    if os.path.exists(CACHE_FILE):
        try:
            with open(CACHE_FILE, "rb") as f:
                obj = pickle.load(f)
            if obj.get("meta",{}).get("xlsx_sig") == sig:
                return obj
        except Exception:
            pass
    idx = build_index_from_excel(xlsx_path)
    try:
        with open(CACHE_FILE, "wb") as f:
            pickle.dump(idx, f, protocol=pickle.HIGHEST_PROTOCOL)
    except Exception:
        pass
    return idx

def score_text(text: str, index: Dict, top_k: int = 40):
    q = _tfidf_vec(tokenize(text), index["idf"])
    scored = []
    for code, dvec in index["docs"].items():
        s = _cosine(q, dvec)
        if s>0:
            scored.append((code, s))
    scored.sort(key=lambda x: x[1], reverse=True)
    return scored[:top_k]

def jsonify_scored(scored, index):
    if not scored:
        return []
    mx = max(s for _, s in scored) or 1.0
    out = []
    for code, s in scored:
        out.append({
            "Deliverable_Code": code,
            "Deliverable_Name": index["names"].get(code, code),
            "confidence": float(s / mx)
        })
    return out
