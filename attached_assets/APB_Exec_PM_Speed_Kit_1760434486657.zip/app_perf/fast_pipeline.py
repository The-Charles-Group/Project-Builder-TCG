
from fastapi import APIRouter, Request, Body
from pydantic import BaseModel
from typing import Optional
from .utils import preload_index, score_text, jsonify_scored

router = APIRouter()

class AnalyzeFastPayload(BaseModel):
    rfp_text: Optional[str] = ""
    re_rank: Optional[bool] = False

@router.post("/analyze_fast2")
async def analyze_fast2(request: Request, payload: AnalyzeFastPayload = Body(...)):
    idx = getattr(request.app.state, "ai_index", None) or preload_index()
    text = (payload.rfp_text or "").strip()
    if not text:
        return {"deliverables": [], "message": "Empty rfp_text"}
    scored = score_text(text, idx, top_k=40)
    out = jsonify_scored(scored, idx)
    return {"deliverables": out, "mode": "fast2", "count": len(out)}
