
# APB — Executive PM Speed Kit (Playbook)

**Goal:** Make Fast mode truly fast (≤2s), keep Deep mode responsive (SSE + parallel), and wire Smart Select.
This kit is industry‑agnostic and does not overfit any one RFP.

See `replit.md` for exact steps for the Replit Agent.
