
import { test, expect } from "@playwright/test";
const APP = process.env.APP_URL || "http://localhost:8000";
test("Fast2 API reachable", async ({ request }) => {
  const res = await request.post(`${APP}/api/ai/analyze_fast2`, {
    data: { rfp_text: "paid media planning and reporting across markets" }
  });
  expect(res.ok()).toBeTruthy();
  const data = await res.json();
  expect(Array.isArray(data.deliverables)).toBeTruthy();
});
