
from locust import HttpUser, task, between
RFP_SNIPPET = "digital marketing with paid media, analytics, reporting, and creative work"
class APBUser(HttpUser):
    wait_time = between(1, 3)
    @task(3)
    def fast2(self):
        self.client.post("/api/ai/analyze_fast2", json={"rfp_text": RFP_SNIPPET})
    @task(1)
    def stream_keepalive(self):
        self.client.get("/api/stream/invalidjobid")
