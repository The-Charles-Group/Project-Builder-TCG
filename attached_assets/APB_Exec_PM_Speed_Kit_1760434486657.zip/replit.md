
# Replit Agent — Execute These Steps Exactly

1) Create/Update files from this kit (paths verbatim).
2) Patch `main.py` to use FastAPI lifespan and preload index/client:

```python
from contextlib import asynccontextmanager
from fastapi import FastAPI
import httpx
from app_perf.utils import preload_index

@asynccontextmanager
async def lifespan(app: FastAPI):
    app.state.http = httpx.AsyncClient(timeout=30.0)
    app.state.ai_index = preload_index()
    app.state.jobs = {}
    yield
    await app.state.http.aclose()

app = FastAPI(lifespan=lifespan)
```

3) Mount routers:
```python
from app_perf.fast_pipeline import router as fast_router
from app_perf.stream import router as stream_router
from app_perf.deep_pipeline import router as deep_router  # optional

app.include_router(fast_router, prefix="/api/ai", tags=["ai-fast2"])
app.include_router(stream_router, prefix="/api/stream", tags=["sse"])
app.include_router(deep_router, prefix="/api/ai", tags=["ai-deep2"])
```

4) Add Smart Select block + scripts to Step 2 page:
```html
<div id="smartSelect">
  <label>Relevancy ≥ <input id="smartThreshold" type="number" min="0" max="100" value="60"></label>%
  <button id="applySmartSelect">Apply Smart Selection</button>
  <span id="smartStats"></span>
</div>
<input id="adminToken" type="password" placeholder="Admin token"/>
<script src="/static/auth_helpers.js"></script>
<script src="/static/smart_select.js"></script>
```

5) Install deps:
```
pip install -U fastapi uvicorn[standard] httpx orjson pymupdf tiktoken
```

6) Run:
```
python -m uvicorn main:app --host 0.0.0.0 --port 8000 --loop uvloop --http httptools
```

7) Verify:
- POST /api/ai/analyze_fast2 → returns deliverables quickly
- GET  /api/stream/{job} → SSE keepalive / partials
- Smart Select selects items at 80/60/40 thresholds

8) Report p95 latencies for Fast2 and note any integration conflicts.
