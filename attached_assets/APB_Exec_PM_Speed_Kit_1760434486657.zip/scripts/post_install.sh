#!/usr/bin/env bash
set -e
pip install -U fastapi uvicorn[standard] httpx orjson pymupdf tiktoken
