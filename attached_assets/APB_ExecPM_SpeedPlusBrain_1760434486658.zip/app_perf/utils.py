
import os, re, math, pickle
from typing import Dict, List, Tuple
import pandas as pd
WORD = re.compile(r"[A-Za-z0-9]{2,}")
def tokenize(t:str)->List[str]: return [x.lower() for x in WORD.findall(t or "")]
def _idf(df:Dict[str,int], N:int)->Dict[str,float]: return {t: math.log((N+1)/(c+1))+1.0 for t,c in df.items()}
def _tfidf(tokens:List[str], idf:Dict[str,float])->Dict[str,float]:
    if not tokens: return {}
    tf={}; 
    for t in tokens:
        if t in idf: tf[t]=tf.get(t,0.0)+1.0
    if not tf: return {}
    inv=1.0/sum(tf.values()); 
    for t in tf: tf[t]*=inv
    return {t: tf[t]*idf[t] for t in tf}
def _cos(q:Dict[str,float], d:Dict[str,float])->float:
    if not q or not d: return 0.0
    num=0.0; qn=0.0; dn=0.0
    for t,w in q.items(): num+=w*d.get(t,0.0); qn+=w*w
    for w in d.values(): dn+=w*w
    return 0.0 if qn<=0 or dn<=0 else num/(math.sqrt(qn*dn))
CACHE_FILE=os.path.join(os.getenv("AI_INDEX_CACHE_DIR","/tmp"),"ai_deliverable_index.pkl")
def _sig(path:str)->str:
    try: import os; st=os.stat(path); return f"{int(st.st_mtime)}:{st.st_size}"
    except: return "0:0"
def build_index(xlsx_path:str)->Dict:
    df = pd.read_excel(xlsx_path, sheet_name=None, engine="openpyxl")
    sheet=None
    for k in df.keys():
        if "index" in k.lower() or "deliver" in k.lower(): sheet=df[k]; break
    if sheet is None: sheet=list(df.values())[0]
    rows=[]
    for _,r in sheet.iterrows():
        code=str(r.get("Deliverable_Code") or r.get("Code") or r.get("ID") or "").strip()
        name=str(r.get("Deliverable_Name") or r.get("Name") or r.get("Title") or "").strip()
        desc=str(r.get("Description") or r.get("Desc") or "").strip()
        if not code and not name: continue
        text=f"{name}\n{desc}".strip()
        rows.append((code or name or f"ROW{len(rows)+1}", name or code or "", text))
    if not rows: raise RuntimeError("No deliverables found")
    df_counts={}; docs={}
    for code,name,text in rows:
        toks=tokenize(text); seen=set()
        for t in toks:
            if t not in seen: df_counts[t]=df_counts.get(t,0)+1; seen.add(t)
        docs[code]={"_name":name,"_tokens":toks}
    N=len(rows); idf=_idf(df_counts,N)
    vecs={}
    for code,info in docs.items(): vecs[code]=_tfidf(info["_tokens"], idf)
    return {"idf":idf,"docs":vecs,"names":{c:docs[c]["_name"] for c in docs},"meta":{"xlsx_sig":_sig(xlsx_path),"N":N}}
def preload_index(xlsx_path:str="AI_Matching_Rules_full.xlsx")->Dict:
    if os.path.exists(CACHE_FILE):
        try:
            obj=pickle.load(open(CACHE_FILE,"rb"))
            if obj.get("meta",{}).get("xlsx_sig")==_sig(xlsx_path): return obj
        except Exception: pass
    idx=build_index(xlsx_path)
    try: pickle.dump(idx, open(CACHE_FILE,"wb"), protocol=pickle.HIGHEST_PROTOCOL)
    except Exception: pass
    return idx
def score_text(text:str, index:Dict, top_k:int=40)->List[Tuple[str,float]]:
    q=_tfidf(tokenize(text), index["idf"]); out=[]
    for code,d in index["docs"].items():
        s=_cos(q,d); 
        if s>0: out.append((code,s))
    out.sort(key=lambda x:x[1], reverse=True)
    return out[:top_k]
def jsonify_scored(scored, index):
    if not scored: return []
    mx=max(s for _,s in scored) or 1.0
    return [{"Deliverable_Code":c, "Deliverable_Name":index["names"].get(c,c), "confidence": float(s/mx)} for c,s in scored]
