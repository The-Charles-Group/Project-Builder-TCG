
from __future__ import annotations
import os, sqlite3, json, time, hashlib, threading
from typing import Any, Dict, List, Tuple
DEFAULT_DB = os.getenv("BRAIN_DB_PATH", "/tmp/brain.sqlite3"); _L = threading.Lock()
SCHEMA = '''
CREATE TABLE IF NOT EXISTS settings(key TEXT PRIMARY KEY, value TEXT);
CREATE TABLE IF NOT EXISTS episodes(id INTEGER PRIMARY KEY AUTOINCREMENT, ts INTEGER, rfp_hash TEXT, industry TEXT, metadata TEXT, selections TEXT);
CREATE TABLE IF NOT EXISTS weights_draft(deliverable_code TEXT, token TEXT, delta REAL, support INTEGER DEFAULT 0, updated_ts INTEGER, PRIMARY KEY(deliverable_code, token));
CREATE TABLE IF NOT EXISTS weights_published(deliverable_code TEXT, token TEXT, delta REAL, support INTEGER DEFAULT 0, updated_ts INTEGER, PRIMARY KEY(deliverable_code, token));
CREATE TABLE IF NOT EXISTS episode_updates(episode_id INTEGER, deliverable_code TEXT, token TEXT, delta_change REAL);
'''
def _c(db=DEFAULT_DB):
    os.makedirs(os.path.dirname(db), exist_ok=True) if os.path.dirname(db) else None
    c = sqlite3.connect(db, check_same_thread=False, timeout=15); c.row_factory = sqlite3.Row; return c
def init(db=DEFAULT_DB):
    with _L:
        c=_c(db); 
        try: 
            for s in SCHEMA.strip().split(';'): s=s.strip(); 
            c.executescript(SCHEMA); c.commit()
        finally: c.close()
def _h(t:str)->str: return hashlib.sha256((t or '').encode('utf-8')).hexdigest()
def get_setting(k:str, d:str="", db=DEFAULT_DB)->str:
    with _L: c=_c(db); 
    try: r=c.execute("SELECT value FROM settings WHERE key=?", (k,)).fetchone(); return r["value"] if r else d
    finally: c.close()
def set_setting(k:str, v:str, db=DEFAULT_DB):
    with _L: c=_c(db); 
    try: c.execute("INSERT OR REPLACE INTO settings(key,value) VALUES(?,?)", (k,v)); c.commit()
    finally: c.close()
def add_episode(rfp_text:str, selections:Dict[str,Any], industry:str|None, metadata:Dict[str,Any], db=DEFAULT_DB)->int:
    with _L: c=_c(db); 
    try: ts=int(time.time()*1000); rh=_h(rfp_text); c.execute(
        "INSERT INTO episodes(ts,rfp_hash,industry,metadata,selections) VALUES(?,?,?,?,?)",
        (ts, rh, industry or "", json.dumps(metadata or {}), json.dumps(selections or {}))); 
        eid=c.execute("SELECT last_insert_rowid() AS id").fetchone()["id"]; c.commit(); return int(eid)
    finally: c.close()
def list_episodes(limit:int=50, offset:int=0, db=DEFAULT_DB)->List[Dict[str,Any]]:
    with _L: c=_c(db); 
    try: rows=c.execute("SELECT * FROM episodes ORDER BY id DESC LIMIT ? OFFSET ?", (limit,offset)).fetchall()
    finally: c.close()
    return [{
        "id":r["id"],"ts":r["ts"],"rfp_hash":r["rfp_hash"],"industry":r["industry"],
        "metadata": json.loads(r["metadata"] or "{}"), "selections": json.loads(r["selections"] or "{}")
    } for r in rows]
def upsert_draft_updates(eid:int, updates:List[Tuple[str,str,float]], support_inc:int=1, db=DEFAULT_DB):
    now=int(time.time()*1000)
    with _L: c=_c(db); 
    try:
        for code,t,dc in updates:
            row=c.execute("SELECT delta,support FROM weights_draft WHERE deliverable_code=? AND token=?", (code,t)).fetchone()
            if row:
                nd=float(row["delta"])+float(dc); ns=int(row["support"])+int(support_inc)
                c.execute("UPDATE weights_draft SET delta=?, support=?, updated_ts=? WHERE deliverable_code=? AND token=?", (nd,ns,now,code,t))
            else:
                c.execute("INSERT INTO weights_draft VALUES(?,?,?,?,?)", (code,t,float(dc),int(support_inc),now))
            c.execute("INSERT INTO episode_updates VALUES(?,?,?,?)", (eid,code,t,float(dc)))
        c.commit()
    finally: c.close()
def publish_draft(db=DEFAULT_DB):
    with _L: c=_c(db); 
    try: c.execute("DELETE FROM weights_published"); 
    finally: c.commit(); c.close()
    with _L: c=_c(db); 
    try: c.execute("INSERT INTO weights_published SELECT * FROM weights_draft"); c.commit()
    finally: c.close()
def reset_all(db=DEFAULT_DB):
    with _L: c=_c(db); 
    try: 
        for t in ("weights_draft","weights_published","episodes","episode_updates"): c.execute(f"DELETE FROM {t}"); c.commit()
    finally: c.close()
def undo_last_episode(db=DEFAULT_DB)->bool:
    with _L: c=_c(db); 
    try:
        row=c.execute("SELECT id FROM episodes ORDER BY id DESC LIMIT 1").fetchone()
        if not row: return False
        eid=int(row["id"])
        upd=c.execute("SELECT deliverable_code,token,delta_change FROM episode_updates WHERE episode_id=?", (eid,)).fetchall()
        for r in upd:
            code,token,chg=r["deliverable_code"],r["token"],float(r["delta_change"])
            row2=c.execute("SELECT delta,support FROM weights_draft WHERE deliverable_code=? AND token=?", (code,token)).fetchone()
            if row2:
                nd=float(row2["delta"])-chg; ns=max(0,int(row2["support"])-1)
                c.execute("UPDATE weights_draft SET delta=?,support=? WHERE deliverable_code=? AND token=?", (nd,ns,code,token))
        c.execute("DELETE FROM episode_updates WHERE episode_id=?", (eid,))
        c.execute("DELETE FROM episodes WHERE id=?", (eid,))
        c.commit(); return True
    finally: c.close()
def get_weights(which:str="published", limit:int=200, db=DEFAULT_DB):
    table="weights_published" if which=="published" else "weights_draft"
    with _L: c=_c(db); 
    try: rows=c.execute(f"SELECT deliverable_code,token,delta,support,updated_ts FROM {table} ORDER BY ABS(delta) DESC LIMIT ?", (limit,)).fetchall()
    finally: c.close()
    return [dict(r) for r in rows]
