
from __future__ import annotations
import os, re, math
from typing import Dict, Any, List, Tuple, Optional
from .brain_store import (init, add_episode, upsert_draft_updates, get_weights, publish_draft, reset_all, undo_last_episode, get_setting, set_setting)
TOKEN_RE = re.compile(r"[A-Za-z0-9\-_\./]{3,}")

def _pf(name:str, default:float)->float:
    v = get_setting(name, os.getenv(name, str(default)))
    try: return float(v)
    except: return float(default)

def _pi(name:str, default:int)->int:
    v = get_setting(name, os.getenv(name, str(default)))
    try: return int(v)
    except: return int(default)

def _mode_default()->str:
    m = get_setting("mode", os.getenv("LEARNING_MODE","off")).strip().lower()
    return m if m in ("off","shadow","active") else "off"

def tokenize(text:str)->List[str]:
    return [t.lower() for t in TOKEN_RE.findall(text or "")][:5000]

def detect_industry(text:str)->Optional[str]:
    tl=(text or "").lower()
    if any(k in tl for k in ("school","admissions","enrollment","university","college")): return "education"
    if any(k in tl for k in ("tequila","vodka","liquor","beverage","bar")): return "beverage"
    if any(k in tl for k in ("donor","fundraising","nonprofit","foundation","charity")): return "nonprofit"
    return None

class LearningBrain:
    def __init__(self):
        init(); self.mode=_mode_default()
    def set_mode(self, mode:str): 
        m=(mode or "off").strip().lower(); 
        if m not in ("off","shadow","active"): m="off"
        set_setting("mode", m); self.mode=m; return {"mode":self.mode}
    def status(self)->Dict[str,Any]:
        return {"mode": self.mode, "params": {
            "LEARNING_DELTA_CAP": _pf("LEARNING_DELTA_CAP",0.30),
            "LEARNING_MIN_SUPPORT": _pi("LEARNING_MIN_SUPPORT",3),
            "LEARNING_RATE": _pf("LEARNING_RATE",0.03),
        }, "top_draft": get_weights("draft",50), "top_published": get_weights("published",50)}
    def set_params(self, params: Dict[str,str])->Dict[str,Any]:
        for k,v in (params or {}).items():
            if k in ("LEARNING_DELTA_CAP","LEARNING_MIN_SUPPORT","LEARNING_RATE"): set_setting(k,str(v))
        return {"message":"params updated", "params": self.status()["params"]}
    def learn(self, rfp_text:str, selected_deliverables:List[str], components_by_deliv:Dict[str,Any]|None, outcome:str, notes:str|None)->Dict[str,Any]:
        ind=detect_industry(rfp_text)
        selections={"deliverables":selected_deliverables or [],"components_by_deliv":components_by_deliv or {}}
        meta={"outcome": outcome or "accepted","notes": notes or ""}
        eid=add_episode(rfp_text,selections,ind,meta)
        if self.mode=="off": return {"message":"learn recorded (mode=off, no updates)","episode_id":eid}
        lr=_pf("LEARNING_RATE",0.03); toks=tokenize(rfp_text); updates=[]
        for code in (selected_deliverables or []):
            for t in toks: updates.append((code,t,lr))
        upsert_draft_updates(eid, updates, support_inc=1)
        return {"message": f"learn recorded (mode={self.mode})", "episode_id": eid, "updates": len(updates)}
    def publish(self)->Dict[str,Any]: publish_draft(); return {"message":"draft → published"}
    def reset(self)->Dict[str,Any]: reset_all(); return {"message":"brain reset"}
    def undo(self)->Dict[str,Any]: return {"message":"undone last episode" if undo_last_episode() else "nothing to undo"}
    def blend_scores(self, base_scores: Dict[str,float], rfp_text:str, which:str="published")->Dict[str,Any]:
        cap=_pf("LEARNING_DELTA_CAP",0.30); min_sup=_pi("LEARNING_MIN_SUPPORT",3)
        tok=set(tokenize(rfp_text)); weights=get_weights(which=which, limit=50000)
        by_code={}
        for w in weights:
            if int(w["support"])<min_sup: continue
            d=float(w["delta"]); 
            if abs(d)>cap: d=cap if d>0 else -cap
            by_code.setdefault(w["deliverable_code"],{})[w["token"]]=d
        scores_out={}; explain={}
        for code, base in base_scores.items():
            contrib=0.0; per_tok={}; m=by_code.get(code) or {}
            for t in tok:
                if t in m: per_tok[t]=m[t]; contrib+=m[t]
            scores_out[code]=float(base)+contrib
            if per_tok: 
                top=dict(sorted(per_tok.items(), key=lambda kv: abs(kv[1]), reverse=True)[:10])
                explain[code]=top
        return {"scores": scores_out, "explain": explain}
