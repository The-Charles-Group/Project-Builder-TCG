
# Steps (Combined)

1) Copy folders into repo root: `learning_brain/`, `app_perf/`, `static/`
2) Patch `main.py`:
```python
from contextlib import asynccontextmanager
from fastapi import FastAPI
import httpx
from app_perf.utils import preload_index

@asynccontextmanager
async def lifespan(app: FastAPI):
    app.state.http = httpx.AsyncClient(timeout=30.0)
    app.state.ai_index = preload_index()
    app.state.jobs = {}
    yield
    await app.state.http.aclose()

app = FastAPI(lifespan=lifespan)

from learning_brain.routes_brain import router as brain_router
from fastapi.staticfiles import StaticFiles
app.include_router(brain_router, prefix="/api/brain", tags=["learning"])
app.mount("/admin/brain", StaticFiles(directory="learning_brain/static", html=True), name="brain_admin")

from app_perf.fast_pipeline import router as fast_router
from app_perf.stream import router as stream_router
app.include_router(fast_router, prefix="/api/ai", tags=["ai-fast2"])
app.include_router(stream_router, prefix="/api/stream", tags=["sse"])
```
3) Add Smart Select block to Step 2 page and include `/static/*.js`.
4) Set env secrets (ADMIN_TOKEN, BRAIN_DB_PATH, LEARNING_MODE, AI_INDEX_CACHE_DIR, PDF_TEXT_CACHE_DIR).
5) Run with uvloop + httptools.
6) Verify Fast2 endpoint + Learning Brain Admin work.
