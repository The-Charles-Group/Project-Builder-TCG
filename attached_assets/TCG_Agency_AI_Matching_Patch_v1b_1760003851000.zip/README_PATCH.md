
# TCG Agency Builder — AI Matching (L1/L2/L3) + Weighted Percentages Patch

This patch adds **rules + lexical scoring** across **all Deliverables (L1), Components (L2), and Tasks (L3)**,
and exposes a new endpoint you can call to render **match percentages** in Step 2.
It also includes data sheets that enumerate the entire catalog (with Service Department).

## What's included

```
data/
  AI_Matching_Rules_full.xlsx   # NEW: AI_Matching_Rules + AI_Index + AI_Config (all L1/L2/L3)
server/
  ai_weighted_matcher.py        # NEW: scoring engine (no external deps)
  routes_weights_fastapi.py     # NEW: FastAPI router for /api/step2/ai/weights
  routes_weights_flask.py       # NEW: Flask Blueprint for /api/step2/ai/weights
static/
  static_weights.js             # NEW: small UI helper to render percentages
  static_weights.css            # NEW: minimal styling
```

## Install (FastAPI)

1. Copy the files into your app:
   - `data/AI_Matching_Rules_full.xlsx` → `./data/`
   - `server/*.py` → your server package (e.g., `./server/`)
   - `static/*` → your static folder

2. Register the router (1 line):

```python
# main.py (FastAPI)
from server.routes_weights_fastapi import router as weights_router
app.include_router(weights_router)  # <-- add this
```

3. Front-end (Step 2A) — show percentages:

```html
<!-- index.html -->
<link rel="stylesheet" href="/static/static_weights.css">
<div id="step2A-weights"></div>
<script src="/static/static_weights.js"></script>
<script>
  async function refreshWeights() {
    const rfp_text = window.getRfpText ? getRfpText() : document.querySelector('#rfpInput').value || '';
    const res = await fetch('/api/step2/ai/weights', {
      method:'POST',
      headers:{'Content-Type':'application/json'},
      body: JSON.stringify({ rfp_text })
    });
    const data = await res.json();
    // Renders Service Department + Deliverable + % (and top components/tasks)
    TCGWeights.render('#step2A-weights', data);
  }
  // Call refreshWeights() after user uploads RFP or edits the Step 1 text box
</script>
```

## Install (Flask)

```python
# app.py (Flask)
from server.routes_weights_flask import bp as weights_bp
app.register_blueprint(weights_bp)
```

## How scoring works

- **AI_Index** (sheet) enumerates **every** L1, L2, L3 with Service Department and default keywords.
- **AI_Matching_Rules** (sheet) contains one rule per **every** L1/L2/L3 (auto-generated from names).  
  You can edit keywords, add `Related_Deliverables`, or narrow matches with `Keywords_All` / `Exclude_Keywords`.
- The engine computes a **rule score** (based on Priority) and a **lexical score** (TF‑IDF similarity),
  then aggregates **L2/L3** contributions into each L1 to produce **Match %** (0–100).  
  Weights live in **AI_Config** and can be tuned without code.

## Showing Service Department

The API returns `service_department` next to each deliverable so the UI can print it in the table.

## Backwards compatibility

- If you already use `/api/step2/ai/suggest`, keep it. The new `/api/step2/ai/weights` is read‑only and does not touch your GPT calls.
- You can later pass the top L1 constraints from this scorer into your GPT component/L3 picker to bias generation.

## Tuning

- Edit `AI_Matching_Rules_full.xlsx` to refine keywords and add relationships.
- Adjust weights in `AI_Config` (e.g., increase `w_rule_*` if you want stricter rule precedence).

## Notes

- The generated rules include *every* L1/L2/L3 with default keywords derived from names and service department.
- For very large catalogs, you can trim low‑value L3 rows from `AI_Matching_Rules` and rely on lexical matching.
