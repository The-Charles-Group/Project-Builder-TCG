
# routes_weights_fastapi.py
# FastAPI router exposing weighted AI match scores for Step 2.

from fastapi import APIRouter, Body
from pydantic import BaseModel
from typing import Optional
import pandas as pd
from .ai_weighted_matcher import score_rfp

router = APIRouter()

class ScoreRequest(BaseModel):
    rfp_text: str
    ai_rules_path: str = "data/AI_Matching_Rules_full.xlsx"

# Expect the app to pass a Deliverable_Index DataFrame (or we read from DB if that's easier).
# To keep this file drop-in, we accept an optional path to the main DB xlsx and read its Deliverable_Index.
def _load_deliverable_index(db_xlsx_path: Optional[str] = None) -> pd.DataFrame | None:
    try:
        if not db_xlsx_path:
            return None
        xls = pd.ExcelFile(db_xlsx_path)
        return pd.read_excel(xls, sheet_name="Deliverable_Index")
    except Exception:
        return None

@router.post("/api/step2/ai/weights")
def api_weights(payload: ScoreRequest = Body(...)):
    # The hosting app can give us DB path via environment or set it here.
    db_path = None  # set this if you want names/departments stitched in
    d_index = _load_deliverable_index(db_path)
    result = score_rfp(payload.rfp_text, payload.ai_rules_path, deliverable_index_df=d_index)
    return result
