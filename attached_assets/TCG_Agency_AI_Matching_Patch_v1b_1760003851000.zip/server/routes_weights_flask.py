
# routes_weights_flask.py
# Flask Blueprint exposing weighted AI match scores for Step 2.

from flask import Blueprint, request, jsonify
import pandas as pd
from .ai_weighted_matcher import score_rfp

bp = Blueprint('weights', __name__)

def _load_deliverable_index(db_xlsx_path=None):
    try:
        if not db_xlsx_path:
            return None
        xls = pd.ExcelFile(db_xlsx_path)
        return pd.read_excel(xls, sheet_name="Deliverable_Index")
    except Exception:
        return None

@bp.route("/api/step2/ai/weights", methods=["POST"])
def api_weights():
    data = request.get_json(force=True) or {}
    rfp_text = data.get("rfp_text","")
    ai_rules_path = data.get("ai_rules_path", "data/AI_Matching_Rules_full.xlsx")
    db_path = None  # set to your DB path if you want names/departments stitched in
    d_index = _load_deliverable_index(db_path)
    result = score_rfp(rfp_text, ai_rules_path, deliverable_index_df=d_index)
    return jsonify(result)
