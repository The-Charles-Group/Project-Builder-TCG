# TCG Relevance Patch V2

## What's Included
- `server/ai_relevance_v2.py` - Enhanced AI relevance scoring engine
- `server/routes_weights_v2_fastapi.py` - FastAPI router for v2 endpoint
- `static/static_weights_v2.js` - Frontend rendering for v2 results
- `static/static_weights_v2.css` - Styling for v2 UI components

## Features
- Department gating with top-2 bonus (1.10×) and penalty (0.35×)
- Execution vs Strategy bias (execution 1.15× bonus, strategy 0.60× penalty)
- Sparsity control (max 4 items in High band ≥85%)
- Budget awareness (over-budget items get 0.60× penalty)
- Hybrid scoring: Weight_Base (rules) + TF-IDF (lexical)

## Installation
1. Copy files to your project structure
2. Add router to main.py:
   ```python
   from server.routes_weights_v2_fastapi import router as weights_v2_router
   app.include_router(weights_v2_router)
   ```
3. Add UI components to index.html (see static files for integration)
4. Endpoint available at `/api/step2/ai/weights_v2`
